from pyrogram.types import InlineKeyboardButton


class Data:
    generate_single_button = [
        InlineKeyboardButton("🔥 START UNTUK MEMBUAT SESSION 🔥", callback_data="generate")
    ]

    home_buttons = [
        generate_single_button,
        [InlineKeyboardButton(text="🏠 KEMBALI 🏠", callback_data="home")],
    ]

    generate_button = [generate_single_button]

    buttons = [
        generate_single_button,
        [
            InlineKeyboardButton(
                "✨ CEK DISINI UNTUK INFO LEBIH LANJUT ✨", url="https://t.me/realenzy"
            )
        ],
        [
            InlineKeyboardButton("🤔 HOW TO USE 🤔", callback_data="help"),
            InlineKeyboardButton("🎪 TENTANG SAYA 🎪", callback_data="about"),
        ],
        [InlineKeyboardButton("💌 SUPPORT 💌", url="https://t.me/titimothy")],
    ]

    START = """
Hai {} 👋
Selamat datang di {}
Saya adalah bot untuk membuat String Session dari PYROGRAM dan TELETHON

PERHATIKAN!!!
1. Bot ini 100% aman digunakan dan sesi kalian tidak saya simpan!!!
2. KALOK GAK PERCAYA GAK USAH PAKEK BLOK !!!
   """

    HELP = """
✨ BANTUAN ✨

/about - Tentang Bot Ini
/help - Pesan Bantuan
/start - Memulai Bot
/generate - Memulai membuat String Session
/cancel - Ya Cancel
/restart - Ya restart
"""

    # About Message
    ABOUT = """
Tentang Bot Ini

Sebuah Bot untuk membuat String Session PYROGRAM dan TELETHON gunakan /start untuk memulai

Framework : [PYROGRAM](docs.pyrogram.org)
Language : [PYTHON](www.python.org)
ᴏᴡɴᴇʀ : @titimothy
    """

    # Repo Message
    REPO = """
Tanya aja ke OWNER
   """